#!/usr/bin/python
import gmpy
import sys
from base64 import b64decode
from binascii import hexlify
import struct

output_files = ['p1.bin', 'p2.bin']


def factor(n):
	t = gmpy.mpz(0)
	
	if n % 2 == 0:
		return 2
	
	r = gmpy.sqrt(n)
	
	if gmpy.is_square(n):
		if gmpy.is_prime(r) > 0:
			return r
		else:
			return factor(r)
	
	r += 1
	
	u = 2*r + 1
	v = gmpy.mpz(1)
	e = r*r - n
	while e != 0:
		while e < 0:
			e += u
			u += 2
		while e > 0:
			e -= v
			v += 2
			
	return (u-v)/2

def factorize(n):
	ret = []
	while gmpy.is_prime(n) == 0:
		t = factor(n)
		if t == 0:
			break
		ret.append(t)
		n = n / t
		ret.append(n)
	return ret
	
if __name__ == '__main__':
	hexdata = hexlify(b64decode(sys.argv[1]))	
	hexchunks = [hexdata[start:start+8] for start in range(0, len(hexdata), 8)]
	hexnumber = '0x'
	for chunk in reversed(hexchunks):
		hexnumber += chunk
	
	number = gmpy.mpz(long(hexnumber, 16))
	print 'Number to factorize: %s' % number
	factors = factorize(number)
	factors.sort()
	for i in range(2):
		print '[*] %s is %s' % (output_files[i].split('.')[0], factors[i])
		f = open(output_files[i], 'wb')
		f.write(factors[i].binary())
		f.close()
		print '[*] %s generated' % output_files[i]
